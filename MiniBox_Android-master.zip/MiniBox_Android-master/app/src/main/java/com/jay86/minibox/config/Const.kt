package com.jay86.minibox.config

/**
 * Created By jay68 on 2017/11/28.
 */
const val SP_DEFAULT_FILENAME = "preference"
const val SP_USER_KEY = "user"