package com.jay86.minibox.network

/**
 * Created By jay68 on 2017/11/22.
 */
class ApiException(status: String, message: String) : Exception(message)