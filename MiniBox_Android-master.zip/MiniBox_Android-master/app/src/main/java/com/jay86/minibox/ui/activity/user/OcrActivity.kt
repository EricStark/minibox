package com.jay86.minibox.ui.activity.user

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.jay86.minibox.R

class OcrActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ocr)
    }
}
